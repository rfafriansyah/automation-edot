const LangDropdown = (props) => {
  const { data } = props;

  return (
    <Dropdown
      options={[
        {
          label: 'English',
          value: 'en'
        }, {
          label: 'Bahasa',
          value: 'id'
        }
      ]}
      selectedOption={{
        label: 'English',
        value: 'en'
      }}
      onClick={() => {}}
      icon={`${data.host}/asset/image/language.svg`}
      locals={data}
      containerClassName="hidden" // TEMPORARILY HIDE DROPDOWN
    />
  )
};
