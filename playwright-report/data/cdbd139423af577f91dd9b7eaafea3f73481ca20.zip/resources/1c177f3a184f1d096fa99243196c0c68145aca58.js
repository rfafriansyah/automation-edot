(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[9293],{7990:function(e,t,r){"use strict";r.d(t,{$s:function(){return S},BH:function(){return m},L:function(){return c},LL:function(){return v},ZR:function(){return y},aH:function(){return p},eu:function(){return w},hl:function(){return b},m9:function(){return E},vZ:function(){return function e(t,r){if(t===r)return!0;let i=Object.keys(t),a=Object.keys(r);for(let n of i){if(!a.includes(n))return!1;let i=t[n],s=r[n];if(_(i)&&_(s)){if(!e(i,s))return!1}else if(i!==s)return!1}for(let e of a)if(!i.includes(e))return!1;return!0}}});var i=r(80581);/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let a=function(e){let t=[],r=0;for(let i=0;i<e.length;i++){let a=e.charCodeAt(i);a<128?t[r++]=a:(a<2048?t[r++]=a>>6|192:((64512&a)==55296&&i+1<e.length&&(64512&e.charCodeAt(i+1))==56320?(a=65536+((1023&a)<<10)+(1023&e.charCodeAt(++i)),t[r++]=a>>18|240,t[r++]=a>>12&63|128):t[r++]=a>>12|224,t[r++]=a>>6&63|128),t[r++]=63&a|128)}return t},n=function(e){let t=[],r=0,i=0;for(;r<e.length;){let a=e[r++];if(a<128)t[i++]=String.fromCharCode(a);else if(a>191&&a<224){let n=e[r++];t[i++]=String.fromCharCode((31&a)<<6|63&n)}else if(a>239&&a<365){let n=e[r++],s=e[r++],o=e[r++],l=((7&a)<<18|(63&n)<<12|(63&s)<<6|63&o)-65536;t[i++]=String.fromCharCode(55296+(l>>10)),t[i++]=String.fromCharCode(56320+(1023&l))}else{let n=e[r++],s=e[r++];t[i++]=String.fromCharCode((15&a)<<12|(63&n)<<6|63&s)}}return t.join("")},s={byteToCharMap_:null,charToByteMap_:null,byteToCharMapWebSafe_:null,charToByteMapWebSafe_:null,ENCODED_VALS_BASE:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",get ENCODED_VALS(){return this.ENCODED_VALS_BASE+"+/="},get ENCODED_VALS_WEBSAFE(){return this.ENCODED_VALS_BASE+"-_."},HAS_NATIVE_SUPPORT:"function"==typeof atob,encodeByteArray(e,t){if(!Array.isArray(e))throw Error("encodeByteArray takes an array as a parameter");this.init_();let r=t?this.byteToCharMapWebSafe_:this.byteToCharMap_,i=[];for(let t=0;t<e.length;t+=3){let a=e[t],n=t+1<e.length,s=n?e[t+1]:0,o=t+2<e.length,l=o?e[t+2]:0,c=a>>2,u=(3&a)<<4|s>>4,h=(15&s)<<2|l>>6,f=63&l;o||(f=64,n||(h=64)),i.push(r[c],r[u],r[h],r[f])}return i.join("")},encodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?btoa(e):this.encodeByteArray(a(e),t)},decodeString(e,t){return this.HAS_NATIVE_SUPPORT&&!t?atob(e):n(this.decodeStringToByteArray(e,t))},decodeStringToByteArray(e,t){this.init_();let r=t?this.charToByteMapWebSafe_:this.charToByteMap_,i=[];for(let t=0;t<e.length;){let a=r[e.charAt(t++)],n=t<e.length,s=n?r[e.charAt(t)]:0;++t;let l=t<e.length,c=l?r[e.charAt(t)]:64;++t;let u=t<e.length,h=u?r[e.charAt(t)]:64;if(++t,null==a||null==s||null==c||null==h)throw new o;let f=a<<2|s>>4;if(i.push(f),64!==c){let e=s<<4&240|c>>2;if(i.push(e),64!==h){let e=c<<6&192|h;i.push(e)}}}return i},init_(){if(!this.byteToCharMap_){this.byteToCharMap_={},this.charToByteMap_={},this.byteToCharMapWebSafe_={},this.charToByteMapWebSafe_={};for(let e=0;e<this.ENCODED_VALS.length;e++)this.byteToCharMap_[e]=this.ENCODED_VALS.charAt(e),this.charToByteMap_[this.byteToCharMap_[e]]=e,this.byteToCharMapWebSafe_[e]=this.ENCODED_VALS_WEBSAFE.charAt(e),this.charToByteMapWebSafe_[this.byteToCharMapWebSafe_[e]]=e,e>=this.ENCODED_VALS_BASE.length&&(this.charToByteMap_[this.ENCODED_VALS_WEBSAFE.charAt(e)]=e,this.charToByteMapWebSafe_[this.ENCODED_VALS.charAt(e)]=e)}}};class o extends Error{constructor(){super(...arguments),this.name="DecodeBase64StringError"}}let l=function(e){let t=a(e);return s.encodeByteArray(t,!0)},c=function(e){return l(e).replace(/\./g,"")},u=function(e){try{return s.decodeString(e,!0)}catch(e){console.error("base64Decode failed: ",e)}return null},h=()=>/**
 * @license
 * Copyright 2022 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(function(){if("undefined"!=typeof self)return self;if("undefined"!=typeof window)return window;if(void 0!==r.g)return r.g;throw Error("Unable to locate global object.")})().__FIREBASE_DEFAULTS__,f=()=>{if(void 0===i||void 0===i.env)return;let e=i.env.__FIREBASE_DEFAULTS__;if(e)return JSON.parse(e)},d=()=>{let e;if("undefined"==typeof document)return;try{e=document.cookie.match(/__FIREBASE_DEFAULTS__=([^;]+)/)}catch(e){return}let t=e&&u(e[1]);return t&&JSON.parse(t)},g=()=>{try{return h()||f()||d()}catch(e){console.info(`Unable to get __FIREBASE_DEFAULTS__ due to: ${e}`);return}},p=()=>{var e;return null===(e=g())||void 0===e?void 0:e.config};/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class m{constructor(){this.reject=()=>{},this.resolve=()=>{},this.promise=new Promise((e,t)=>{this.resolve=e,this.reject=t})}wrapCallback(e){return(t,r)=>{t?this.reject(t):this.resolve(r),"function"==typeof e&&(this.promise.catch(()=>{}),1===e.length?e(t):e(t,r))}}}function b(){try{return"object"==typeof indexedDB}catch(e){return!1}}function w(){return new Promise((e,t)=>{try{let r=!0,i="validate-browser-context-for-indexeddb-analytics-module",a=self.indexedDB.open(i);a.onsuccess=()=>{a.result.close(),r||self.indexedDB.deleteDatabase(i),e(!0)},a.onupgradeneeded=()=>{r=!1},a.onerror=()=>{var e;t((null===(e=a.error)||void 0===e?void 0:e.message)||"")}}catch(e){t(e)}})}class y extends Error{constructor(e,t,r){super(t),this.code=e,this.customData=r,this.name="FirebaseError",Object.setPrototypeOf(this,y.prototype),Error.captureStackTrace&&Error.captureStackTrace(this,v.prototype.create)}}class v{constructor(e,t,r){this.service=e,this.serviceName=t,this.errors=r}create(e,...t){let r=t[0]||{},i=`${this.service}/${e}`,a=this.errors[e],n=a?a.replace(C,(e,t)=>{let i=r[t];return null!=i?String(i):`<${t}?>`}):"Error",s=`${this.serviceName}: ${n} (${i}).`,o=new y(i,s,r);return o}}let C=/\{\$([^}]+)}/g;function _(e){return null!==e&&"object"==typeof e}function S(e,t=1e3,r=2){let i=t*Math.pow(r,e);return Math.min(144e5,i+Math.round(.5*i*(Math.random()-.5)*2))}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function E(e){return e&&e._delegate?e._delegate:e}},64909:function(e,t,r){e.exports=r(5929)},92515:function(e,t,r){"use strict";r.d(t,{Jn:function(){return C},KN:function(){return E},Mq:function(){return S},Xd:function(){return b},ZF:function(){return _},qX:function(){return w}});var i=r(99686),a=r(24833),n=r(7990),s=r(80686);/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class o{constructor(e){this.container=e}getPlatformInfoString(){let e=this.container.getProviders();return e.map(e=>{if(!function(e){let t=e.getComponent();return(null==t?void 0:t.type)==="VERSION"}(e))return null;{let t=e.getImmediate();return`${t.library}/${t.version}`}}).filter(e=>e).join(" ")}}let l="@firebase/app",c="0.10.13",u=new a.Yd("@firebase/app"),h="[DEFAULT]",f={[l]:"fire-core","@firebase/app-compat":"fire-core-compat","@firebase/analytics":"fire-analytics","@firebase/analytics-compat":"fire-analytics-compat","@firebase/app-check":"fire-app-check","@firebase/app-check-compat":"fire-app-check-compat","@firebase/auth":"fire-auth","@firebase/auth-compat":"fire-auth-compat","@firebase/database":"fire-rtdb","@firebase/data-connect":"fire-data-connect","@firebase/database-compat":"fire-rtdb-compat","@firebase/functions":"fire-fn","@firebase/functions-compat":"fire-fn-compat","@firebase/installations":"fire-iid","@firebase/installations-compat":"fire-iid-compat","@firebase/messaging":"fire-fcm","@firebase/messaging-compat":"fire-fcm-compat","@firebase/performance":"fire-perf","@firebase/performance-compat":"fire-perf-compat","@firebase/remote-config":"fire-rc","@firebase/remote-config-compat":"fire-rc-compat","@firebase/storage":"fire-gcs","@firebase/storage-compat":"fire-gcs-compat","@firebase/firestore":"fire-fst","@firebase/firestore-compat":"fire-fst-compat","@firebase/vertexai-preview":"fire-vertex","fire-js":"fire-js",firebase:"fire-js-all"},d=new Map,g=new Map,p=new Map;function m(e,t){try{e.container.addComponent(t)}catch(r){u.debug(`Component ${t.name} failed to register with FirebaseApp ${e.name}`,r)}}function b(e){let t=e.name;if(p.has(t))return u.debug(`There were multiple attempts to register component ${t}.`),!1;for(let r of(p.set(t,e),d.values()))m(r,e);for(let t of g.values())m(t,e);return!0}function w(e,t){let r=e.container.getProvider("heartbeat").getImmediate({optional:!0});return r&&r.triggerHeartbeat(),e.container.getProvider(t)}let y=new n.LL("app","Firebase",{"no-app":"No Firebase App '{$appName}' has been created - call initializeApp() first","bad-app-name":"Illegal App name: '{$appName}'","duplicate-app":"Firebase App named '{$appName}' already exists with different options or config","app-deleted":"Firebase App named '{$appName}' already deleted","server-app-deleted":"Firebase Server App has been deleted","no-options":"Need to provide options, when not being deployed to hosting via source.","invalid-app-argument":"firebase.{$appName}() takes either no argument or a Firebase App instance.","invalid-log-argument":"First argument to `onLog` must be null or a function.","idb-open":"Error thrown when opening IndexedDB. Original error: {$originalErrorMessage}.","idb-get":"Error thrown when reading from IndexedDB. Original error: {$originalErrorMessage}.","idb-set":"Error thrown when writing to IndexedDB. Original error: {$originalErrorMessage}.","idb-delete":"Error thrown when deleting from IndexedDB. Original error: {$originalErrorMessage}.","finalization-registry-not-supported":"FirebaseServerApp deleteOnDeref field defined but the JS runtime does not support FinalizationRegistry.","invalid-server-app-environment":"FirebaseServerApp is not for use in browser environments."});/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class v{constructor(e,t,r){this._isDeleted=!1,this._options=Object.assign({},e),this._config=Object.assign({},t),this._name=t.name,this._automaticDataCollectionEnabled=t.automaticDataCollectionEnabled,this._container=r,this.container.addComponent(new i.wA("app",()=>this,"PUBLIC"))}get automaticDataCollectionEnabled(){return this.checkDestroyed(),this._automaticDataCollectionEnabled}set automaticDataCollectionEnabled(e){this.checkDestroyed(),this._automaticDataCollectionEnabled=e}get name(){return this.checkDestroyed(),this._name}get options(){return this.checkDestroyed(),this._options}get config(){return this.checkDestroyed(),this._config}get container(){return this._container}get isDeleted(){return this._isDeleted}set isDeleted(e){this._isDeleted=e}checkDestroyed(){if(this.isDeleted)throw y.create("app-deleted",{appName:this._name})}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let C="10.14.1";function _(e,t={}){let r=e;if("object"!=typeof t){let e=t;t={name:e}}let a=Object.assign({name:h,automaticDataCollectionEnabled:!1},t),s=a.name;if("string"!=typeof s||!s)throw y.create("bad-app-name",{appName:String(s)});if(r||(r=(0,n.aH)()),!r)throw y.create("no-options");let o=d.get(s);if(o){if((0,n.vZ)(r,o.options)&&(0,n.vZ)(a,o.config))return o;throw y.create("duplicate-app",{appName:s})}let l=new i.H0(s);for(let e of p.values())l.addComponent(e);let c=new v(r,a,l);return d.set(s,c),c}function S(e=h){let t=d.get(e);if(!t&&e===h&&(0,n.aH)())return _();if(!t)throw y.create("no-app",{appName:e});return t}function E(e,t,r){var a;let n=null!==(a=f[e])&&void 0!==a?a:e;r&&(n+=`-${r}`);let s=n.match(/\s|\//),o=t.match(/\s|\//);if(s||o){let e=[`Unable to register library "${n}" with version "${t}":`];s&&e.push(`library name "${n}" contains illegal characters (whitespace or "/")`),s&&o&&e.push("and"),o&&e.push(`version name "${t}" contains illegal characters (whitespace or "/")`),u.warn(e.join(" "));return}b(new i.wA(`${n}-version`,()=>({library:n,version:t}),"VERSION"))}let I="firebase-heartbeat-store",D=null;function A(){return D||(D=(0,s.X3)("firebase-heartbeat-database",1,{upgrade:(e,t)=>{if(0===t)try{e.createObjectStore(I)}catch(e){console.warn(e)}}}).catch(e=>{throw y.create("idb-open",{originalErrorMessage:e.message})})),D}async function T(e){try{let t=await A(),r=t.transaction(I),i=await r.objectStore(I).get(M(e));return await r.done,i}catch(e){if(e instanceof n.ZR)u.warn(e.message);else{let t=y.create("idb-get",{originalErrorMessage:null==e?void 0:e.message});u.warn(t.message)}}}async function O(e,t){try{let r=await A(),i=r.transaction(I,"readwrite"),a=i.objectStore(I);await a.put(t,M(e)),await i.done}catch(e){if(e instanceof n.ZR)u.warn(e.message);else{let t=y.create("idb-set",{originalErrorMessage:null==e?void 0:e.message});u.warn(t.message)}}}function M(e){return`${e.name}!${e.options.appId}`}class L{constructor(e){this.container=e,this._heartbeatsCache=null;let t=this.container.getProvider("app").getImmediate();this._storage=new P(t),this._heartbeatsCachePromise=this._storage.read().then(e=>(this._heartbeatsCache=e,e))}async triggerHeartbeat(){var e,t;try{let r=this.container.getProvider("platform-logger").getImmediate(),i=r.getPlatformInfoString(),a=F();if((null===(e=this._heartbeatsCache)||void 0===e?void 0:e.heartbeats)==null&&(this._heartbeatsCache=await this._heartbeatsCachePromise,(null===(t=this._heartbeatsCache)||void 0===t?void 0:t.heartbeats)==null)||this._heartbeatsCache.lastSentHeartbeatDate===a||this._heartbeatsCache.heartbeats.some(e=>e.date===a))return;return this._heartbeatsCache.heartbeats.push({date:a,agent:i}),this._heartbeatsCache.heartbeats=this._heartbeatsCache.heartbeats.filter(e=>{let t=new Date(e.date).valueOf(),r=Date.now();return r-t<=2592e6}),this._storage.overwrite(this._heartbeatsCache)}catch(e){u.warn(e)}}async getHeartbeatsHeader(){var e;try{if(null===this._heartbeatsCache&&await this._heartbeatsCachePromise,(null===(e=this._heartbeatsCache)||void 0===e?void 0:e.heartbeats)==null||0===this._heartbeatsCache.heartbeats.length)return"";let t=F(),{heartbeatsToSend:r,unsentEntries:i}=function(e,t=1024){let r=[],i=e.slice();for(let a of e){let e=r.find(e=>e.agent===a.agent);if(e){if(e.dates.push(a.date),N(r)>t){e.dates.pop();break}}else if(r.push({agent:a.agent,dates:[a.date]}),N(r)>t){r.pop();break}i=i.slice(1)}return{heartbeatsToSend:r,unsentEntries:i}}(this._heartbeatsCache.heartbeats),a=(0,n.L)(JSON.stringify({version:2,heartbeats:r}));return this._heartbeatsCache.lastSentHeartbeatDate=t,i.length>0?(this._heartbeatsCache.heartbeats=i,await this._storage.overwrite(this._heartbeatsCache)):(this._heartbeatsCache.heartbeats=[],this._storage.overwrite(this._heartbeatsCache)),a}catch(e){return u.warn(e),""}}}function F(){let e=new Date;return e.toISOString().substring(0,10)}class P{constructor(e){this.app=e,this._canUseIndexedDBPromise=this.runIndexedDBEnvironmentCheck()}async runIndexedDBEnvironmentCheck(){return!!(0,n.hl)()&&(0,n.eu)().then(()=>!0).catch(()=>!1)}async read(){let e=await this._canUseIndexedDBPromise;if(!e)return{heartbeats:[]};{let e=await T(this.app);return(null==e?void 0:e.heartbeats)?e:{heartbeats:[]}}}async overwrite(e){var t;let r=await this._canUseIndexedDBPromise;if(r){let r=await this.read();return O(this.app,{lastSentHeartbeatDate:null!==(t=e.lastSentHeartbeatDate)&&void 0!==t?t:r.lastSentHeartbeatDate,heartbeats:e.heartbeats})}}async add(e){var t;let r=await this._canUseIndexedDBPromise;if(r){let r=await this.read();return O(this.app,{lastSentHeartbeatDate:null!==(t=e.lastSentHeartbeatDate)&&void 0!==t?t:r.lastSentHeartbeatDate,heartbeats:[...r.heartbeats,...e.heartbeats]})}}}function N(e){return(0,n.L)(JSON.stringify({version:2,heartbeats:e})).length}b(new i.wA("platform-logger",e=>new o(e),"PRIVATE")),b(new i.wA("heartbeat",e=>new L(e),"PRIVATE")),E(l,c,""),E(l,c,"esm2017"),E("fire-js","")},99686:function(e,t,r){"use strict";r.d(t,{H0:function(){return o},wA:function(){return a}});var i=r(7990);class a{constructor(e,t,r){this.name=e,this.instanceFactory=t,this.type=r,this.multipleInstances=!1,this.serviceProps={},this.instantiationMode="LAZY",this.onInstanceCreated=null}setInstantiationMode(e){return this.instantiationMode=e,this}setMultipleInstances(e){return this.multipleInstances=e,this}setServiceProps(e){return this.serviceProps=e,this}setInstanceCreatedCallback(e){return this.onInstanceCreated=e,this}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let n="[DEFAULT]";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class s{constructor(e,t){this.name=e,this.container=t,this.component=null,this.instances=new Map,this.instancesDeferred=new Map,this.instancesOptions=new Map,this.onInitCallbacks=new Map}get(e){let t=this.normalizeInstanceIdentifier(e);if(!this.instancesDeferred.has(t)){let e=new i.BH;if(this.instancesDeferred.set(t,e),this.isInitialized(t)||this.shouldAutoInitialize())try{let r=this.getOrInitializeService({instanceIdentifier:t});r&&e.resolve(r)}catch(e){}}return this.instancesDeferred.get(t).promise}getImmediate(e){var t;let r=this.normalizeInstanceIdentifier(null==e?void 0:e.identifier),i=null!==(t=null==e?void 0:e.optional)&&void 0!==t&&t;if(this.isInitialized(r)||this.shouldAutoInitialize())try{return this.getOrInitializeService({instanceIdentifier:r})}catch(e){if(i)return null;throw e}else{if(i)return null;throw Error(`Service ${this.name} is not available`)}}getComponent(){return this.component}setComponent(e){if(e.name!==this.name)throw Error(`Mismatching Component ${e.name} for Provider ${this.name}.`);if(this.component)throw Error(`Component for ${this.name} has already been provided`);if(this.component=e,this.shouldAutoInitialize()){if("EAGER"===e.instantiationMode)try{this.getOrInitializeService({instanceIdentifier:n})}catch(e){}for(let[e,t]of this.instancesDeferred.entries()){let r=this.normalizeInstanceIdentifier(e);try{let e=this.getOrInitializeService({instanceIdentifier:r});t.resolve(e)}catch(e){}}}}clearInstance(e=n){this.instancesDeferred.delete(e),this.instancesOptions.delete(e),this.instances.delete(e)}async delete(){let e=Array.from(this.instances.values());await Promise.all([...e.filter(e=>"INTERNAL"in e).map(e=>e.INTERNAL.delete()),...e.filter(e=>"_delete"in e).map(e=>e._delete())])}isComponentSet(){return null!=this.component}isInitialized(e=n){return this.instances.has(e)}getOptions(e=n){return this.instancesOptions.get(e)||{}}initialize(e={}){let{options:t={}}=e,r=this.normalizeInstanceIdentifier(e.instanceIdentifier);if(this.isInitialized(r))throw Error(`${this.name}(${r}) has already been initialized`);if(!this.isComponentSet())throw Error(`Component ${this.name} has not been registered yet`);let i=this.getOrInitializeService({instanceIdentifier:r,options:t});for(let[e,t]of this.instancesDeferred.entries()){let a=this.normalizeInstanceIdentifier(e);r===a&&t.resolve(i)}return i}onInit(e,t){var r;let i=this.normalizeInstanceIdentifier(t),a=null!==(r=this.onInitCallbacks.get(i))&&void 0!==r?r:new Set;a.add(e),this.onInitCallbacks.set(i,a);let n=this.instances.get(i);return n&&e(n,i),()=>{a.delete(e)}}invokeOnInitCallbacks(e,t){let r=this.onInitCallbacks.get(t);if(r)for(let i of r)try{i(e,t)}catch(e){}}getOrInitializeService({instanceIdentifier:e,options:t={}}){let r=this.instances.get(e);if(!r&&this.component&&(r=this.component.instanceFactory(this.container,{instanceIdentifier:e===n?void 0:e,options:t}),this.instances.set(e,r),this.instancesOptions.set(e,t),this.invokeOnInitCallbacks(r,e),this.component.onInstanceCreated))try{this.component.onInstanceCreated(this.container,e,r)}catch(e){}return r||null}normalizeInstanceIdentifier(e=n){return this.component?this.component.multipleInstances?e:n:e}shouldAutoInitialize(){return!!this.component&&"EXPLICIT"!==this.component.instantiationMode}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class o{constructor(e){this.name=e,this.providers=new Map}addComponent(e){let t=this.getProvider(e.name);if(t.isComponentSet())throw Error(`Component ${e.name} has already been registered with ${this.name}`);t.setComponent(e)}addOrOverwriteComponent(e){let t=this.getProvider(e.name);t.isComponentSet()&&this.providers.delete(e.name),this.addComponent(e)}getProvider(e){if(this.providers.has(e))return this.providers.get(e);let t=new s(e,this);return this.providers.set(e,t),t}getProviders(){return Array.from(this.providers.values())}}},24833:function(e,t,r){"use strict";var i,a;r.d(t,{Yd:function(){return u},in:function(){return i}});/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let n=[];(a=i||(i={}))[a.DEBUG=0]="DEBUG",a[a.VERBOSE=1]="VERBOSE",a[a.INFO=2]="INFO",a[a.WARN=3]="WARN",a[a.ERROR=4]="ERROR",a[a.SILENT=5]="SILENT";let s={debug:i.DEBUG,verbose:i.VERBOSE,info:i.INFO,warn:i.WARN,error:i.ERROR,silent:i.SILENT},o=i.INFO,l={[i.DEBUG]:"log",[i.VERBOSE]:"log",[i.INFO]:"info",[i.WARN]:"warn",[i.ERROR]:"error"},c=(e,t,...r)=>{if(t<e.logLevel)return;let i=new Date().toISOString(),a=l[t];if(a)console[a](`[${i}]  ${e.name}:`,...r);else throw Error(`Attempted to log a message with an invalid logType (value: ${t})`)};class u{constructor(e){this.name=e,this._logLevel=o,this._logHandler=c,this._userLogHandler=null,n.push(this)}get logLevel(){return this._logLevel}set logLevel(e){if(!(e in i))throw TypeError(`Invalid value "${e}" assigned to \`logLevel\``);this._logLevel=e}setLogLevel(e){this._logLevel="string"==typeof e?s[e]:e}get logHandler(){return this._logHandler}set logHandler(e){if("function"!=typeof e)throw TypeError("Value assigned to `logHandler` must be a function");this._logHandler=e}get userLogHandler(){return this._userLogHandler}set userLogHandler(e){this._userLogHandler=e}debug(...e){this._userLogHandler&&this._userLogHandler(this,i.DEBUG,...e),this._logHandler(this,i.DEBUG,...e)}log(...e){this._userLogHandler&&this._userLogHandler(this,i.VERBOSE,...e),this._logHandler(this,i.VERBOSE,...e)}info(...e){this._userLogHandler&&this._userLogHandler(this,i.INFO,...e),this._logHandler(this,i.INFO,...e)}warn(...e){this._userLogHandler&&this._userLogHandler(this,i.WARN,...e),this._logHandler(this,i.WARN,...e)}error(...e){this._userLogHandler&&this._userLogHandler(this,i.ERROR,...e),this._logHandler(this,i.ERROR,...e)}}},91351:function(e,t,r){"use strict";r.d(t,{Ee:function(){return Image},NY:function(){return v},fC:function(){return y}});var i=r(5350),a=r(30878),n=r(233),s=r(64859),o=r(19945),l=r(58387),c="Avatar",[u,h]=(0,a.b)(c),[f,d]=u(c),g=i.forwardRef((e,t)=>{let{__scopeAvatar:r,...a}=e,[n,s]=i.useState("idle");return(0,l.jsx)(f,{scope:r,imageLoadingStatus:n,onImageLoadingStatusChange:s,children:(0,l.jsx)(o.WV.span,{...a,ref:t})})});g.displayName=c;var p="AvatarImage",m=i.forwardRef((e,t)=>{let{__scopeAvatar:r,src:a,onLoadingStatusChange:c=()=>{},...u}=e,h=d(p,r),f=function(e,t){let[r,a]=i.useState("idle");return(0,s.b)(()=>{if(!e){a("error");return}let r=!0,i=new window.Image,n=e=>()=>{r&&a(e)};return a("loading"),i.onload=n("loaded"),i.onerror=n("error"),i.src=e,t&&(i.referrerPolicy=t),()=>{r=!1}},[e,t]),r}(a,u.referrerPolicy),g=(0,n.W)(e=>{c(e),h.onImageLoadingStatusChange(e)});return(0,s.b)(()=>{"idle"!==f&&g(f)},[f,g]),"loaded"===f?(0,l.jsx)(o.WV.img,{...u,ref:t,src:a}):null});m.displayName=p;var b="AvatarFallback",w=i.forwardRef((e,t)=>{let{__scopeAvatar:r,delayMs:a,...n}=e,s=d(b,r),[c,u]=i.useState(void 0===a);return i.useEffect(()=>{if(void 0!==a){let e=window.setTimeout(()=>u(!0),a);return()=>window.clearTimeout(e)}},[a]),c&&"loaded"!==s.imageLoadingStatus?(0,l.jsx)(o.WV.span,{...n,ref:t}):null});w.displayName=b;var y=g,Image=m,v=w},83501:function(e,t,r){"use strict";r.d(t,{S:function(){return g}});var i=r(42745),a=r(82375),n=r(4845),s=r(31049),o=class extends s.l{constructor(e={}){super(),this.config=e,this.#e=new Map}#e;build(e,t,r){let n=t.queryKey,s=t.queryHash??(0,i.Rm)(n,t),o=this.get(s);return o||(o=new a.A({client:e,queryKey:n,queryHash:s,options:e.defaultQueryOptions(t),state:r,defaultOptions:e.getQueryDefaults(n)}),this.add(o)),o}add(e){this.#e.has(e.queryHash)||(this.#e.set(e.queryHash,e),this.notify({type:"added",query:e}))}remove(e){let t=this.#e.get(e.queryHash);t&&(e.destroy(),t===e&&this.#e.delete(e.queryHash),this.notify({type:"removed",query:e}))}clear(){n.Vr.batch(()=>{this.getAll().forEach(e=>{this.remove(e)})})}get(e){return this.#e.get(e)}getAll(){return[...this.#e.values()]}find(e){let t={exact:!0,...e};return this.getAll().find(e=>(0,i._x)(t,e))}findAll(e={}){let t=this.getAll();return Object.keys(e).length>0?t.filter(t=>(0,i._x)(e,t)):t}notify(e){n.Vr.batch(()=>{this.listeners.forEach(t=>{t(e)})})}onFocus(){n.Vr.batch(()=>{this.getAll().forEach(e=>{e.onFocus()})})}onOnline(){n.Vr.batch(()=>{this.getAll().forEach(e=>{e.onOnline()})})}},l=r(53327),c=class extends s.l{constructor(e={}){super(),this.config=e,this.#t=new Set,this.#r=new Map,this.#i=0}#t;#r;#i;build(e,t,r){let i=new l.m({mutationCache:this,mutationId:++this.#i,options:e.defaultMutationOptions(t),state:r});return this.add(i),i}add(e){this.#t.add(e);let t=u(e);if("string"==typeof t){let r=this.#r.get(t);r?r.push(e):this.#r.set(t,[e])}this.notify({type:"added",mutation:e})}remove(e){if(this.#t.delete(e)){let t=u(e);if("string"==typeof t){let r=this.#r.get(t);if(r){if(r.length>1){let t=r.indexOf(e);-1!==t&&r.splice(t,1)}else r[0]===e&&this.#r.delete(t)}}}this.notify({type:"removed",mutation:e})}canRun(e){let t=u(e);if("string"!=typeof t)return!0;{let r=this.#r.get(t),i=r?.find(e=>"pending"===e.state.status);return!i||i===e}}runNext(e){let t=u(e);if("string"!=typeof t)return Promise.resolve();{let r=this.#r.get(t)?.find(t=>t!==e&&t.state.isPaused);return r?.continue()??Promise.resolve()}}clear(){n.Vr.batch(()=>{this.#t.forEach(e=>{this.notify({type:"removed",mutation:e})}),this.#t.clear(),this.#r.clear()})}getAll(){return Array.from(this.#t)}find(e){let t={exact:!0,...e};return this.getAll().find(e=>(0,i.X7)(t,e))}findAll(e={}){return this.getAll().filter(t=>(0,i.X7)(e,t))}notify(e){n.Vr.batch(()=>{this.listeners.forEach(t=>{t(e)})})}resumePausedMutations(){let e=this.getAll().filter(e=>e.state.isPaused);return n.Vr.batch(()=>Promise.all(e.map(e=>e.continue().catch(i.ZT))))}};function u(e){return e.options.scope?.id}var h=r(26458),f=r(60055),d=r(81845),g=class{#a;#n;#s;#o;#l;#c;#u;#h;constructor(e={}){this.#a=e.queryCache||new o,this.#n=e.mutationCache||new c,this.#s=e.defaultOptions||{},this.#o=new Map,this.#l=new Map,this.#c=0}mount(){this.#c++,1===this.#c&&(this.#u=h.j.subscribe(async e=>{e&&(await this.resumePausedMutations(),this.#a.onFocus())}),this.#h=f.N.subscribe(async e=>{e&&(await this.resumePausedMutations(),this.#a.onOnline())}))}unmount(){this.#c--,0===this.#c&&(this.#u?.(),this.#u=void 0,this.#h?.(),this.#h=void 0)}isFetching(e){return this.#a.findAll({...e,fetchStatus:"fetching"}).length}isMutating(e){return this.#n.findAll({...e,status:"pending"}).length}getQueryData(e){let t=this.defaultQueryOptions({queryKey:e});return this.#a.get(t.queryHash)?.state.data}ensureQueryData(e){let t=this.defaultQueryOptions(e),r=this.#a.build(this,t),a=r.state.data;return void 0===a?this.fetchQuery(e):(e.revalidateIfStale&&r.isStaleByTime((0,i.KC)(t.staleTime,r))&&this.prefetchQuery(t),Promise.resolve(a))}getQueriesData(e){return this.#a.findAll(e).map(({queryKey:e,state:t})=>{let r=t.data;return[e,r]})}setQueryData(e,t,r){let a=this.defaultQueryOptions({queryKey:e}),n=this.#a.get(a.queryHash),s=n?.state.data,o=(0,i.SE)(t,s);if(void 0!==o)return this.#a.build(this,a).setData(o,{...r,manual:!0})}setQueriesData(e,t,r){return n.Vr.batch(()=>this.#a.findAll(e).map(({queryKey:e})=>[e,this.setQueryData(e,t,r)]))}getQueryState(e){let t=this.defaultQueryOptions({queryKey:e});return this.#a.get(t.queryHash)?.state}removeQueries(e){let t=this.#a;n.Vr.batch(()=>{t.findAll(e).forEach(e=>{t.remove(e)})})}resetQueries(e,t){let r=this.#a;return n.Vr.batch(()=>(r.findAll(e).forEach(e=>{e.reset()}),this.refetchQueries({type:"active",...e},t)))}cancelQueries(e,t={}){let r={revert:!0,...t},a=n.Vr.batch(()=>this.#a.findAll(e).map(e=>e.cancel(r)));return Promise.all(a).then(i.ZT).catch(i.ZT)}invalidateQueries(e,t={}){return n.Vr.batch(()=>(this.#a.findAll(e).forEach(e=>{e.invalidate()}),e?.refetchType==="none")?Promise.resolve():this.refetchQueries({...e,type:e?.refetchType??e?.type??"active"},t))}refetchQueries(e,t={}){let r={...t,cancelRefetch:t.cancelRefetch??!0},a=n.Vr.batch(()=>this.#a.findAll(e).filter(e=>!e.isDisabled()).map(e=>{let t=e.fetch(void 0,r);return r.throwOnError||(t=t.catch(i.ZT)),"paused"===e.state.fetchStatus?Promise.resolve():t}));return Promise.all(a).then(i.ZT)}fetchQuery(e){let t=this.defaultQueryOptions(e);void 0===t.retry&&(t.retry=!1);let r=this.#a.build(this,t);return r.isStaleByTime((0,i.KC)(t.staleTime,r))?r.fetch(t):Promise.resolve(r.state.data)}prefetchQuery(e){return this.fetchQuery(e).then(i.ZT).catch(i.ZT)}fetchInfiniteQuery(e){return e.behavior=(0,d.Gm)(e.pages),this.fetchQuery(e)}prefetchInfiniteQuery(e){return this.fetchInfiniteQuery(e).then(i.ZT).catch(i.ZT)}ensureInfiniteQueryData(e){return e.behavior=(0,d.Gm)(e.pages),this.ensureQueryData(e)}resumePausedMutations(){return f.N.isOnline()?this.#n.resumePausedMutations():Promise.resolve()}getQueryCache(){return this.#a}getMutationCache(){return this.#n}getDefaultOptions(){return this.#s}setDefaultOptions(e){this.#s=e}setQueryDefaults(e,t){this.#o.set((0,i.Ym)(e),{queryKey:e,defaultOptions:t})}getQueryDefaults(e){let t=[...this.#o.values()],r={};return t.forEach(t=>{(0,i.to)(e,t.queryKey)&&Object.assign(r,t.defaultOptions)}),r}setMutationDefaults(e,t){this.#l.set((0,i.Ym)(e),{mutationKey:e,defaultOptions:t})}getMutationDefaults(e){let t=[...this.#l.values()],r={};return t.forEach(t=>{(0,i.to)(e,t.mutationKey)&&Object.assign(r,t.defaultOptions)}),r}defaultQueryOptions(e){if(e._defaulted)return e;let t={...this.#s.queries,...this.getQueryDefaults(e.queryKey),...e,_defaulted:!0};return t.queryHash||(t.queryHash=(0,i.Rm)(t.queryKey,t)),void 0===t.refetchOnReconnect&&(t.refetchOnReconnect="always"!==t.networkMode),void 0===t.throwOnError&&(t.throwOnError=!!t.suspense),!t.networkMode&&t.persister&&(t.networkMode="offlineFirst"),t.queryFn===i.CN&&(t.enabled=!1),t}defaultMutationOptions(e){return e?._defaulted?e:{...this.#s.mutations,...e?.mutationKey&&this.getMutationDefaults(e.mutationKey),...e,_defaulted:!0}}clear(){this.#a.clear(),this.#n.clear()}}},93851:function(e,t,r){"use strict";r.d(t,{t:function(){return i}});var i=function(){return null}},51893:function(e,t,r){"use strict";r.d(t,{ZF:function(){return i.ZF}});var i=r(92515);/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */(0,i.KN)("firebase","10.14.1","app")},92658:function(e,t,r){"use strict";r.d(t,{xS:function(){return ed},sN:function(){return er},NA:function(){return en}});var i=r(92515),a=r(7990),n=r(99686),s=r(24833),o=r(80686);let l="@firebase/installations",c="0.6.9",u=`w:${c}`,h="FIS_v2",f=new a.LL("installations","Installations",{"missing-app-config-values":'Missing App configuration value: "{$valueName}"',"not-registered":"Firebase Installation is not registered.","installation-not-found":"Firebase Installation not found.","request-failed":'{$requestName} request failed with error "{$serverCode} {$serverStatus}: {$serverMessage}"',"app-offline":"Could not process request. Application offline.","delete-pending-registration":"Can't delete installation while there is a pending registration request."});function d(e){return e instanceof a.ZR&&e.code.includes("request-failed")}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function g({projectId:e}){return`https://firebaseinstallations.googleapis.com/v1/projects/${e}/installations`}function p(e){return{token:e.token,requestStatus:2,expiresIn:Number(e.expiresIn.replace("s","000")),creationTime:Date.now()}}async function m(e,t){let r=await t.json(),i=r.error;return f.create("request-failed",{requestName:e,serverCode:i.code,serverMessage:i.message,serverStatus:i.status})}function b({apiKey:e}){return new Headers({"Content-Type":"application/json",Accept:"application/json","x-goog-api-key":e})}async function w(e){let t=await e();return t.status>=500&&t.status<600?e():t}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function y({appConfig:e,heartbeatServiceProvider:t},{fid:r}){let i=g(e),a=b(e),n=t.getImmediate({optional:!0});if(n){let e=await n.getHeartbeatsHeader();e&&a.append("x-firebase-client",e)}let s={fid:r,authVersion:h,appId:e.appId,sdkVersion:u},o={method:"POST",headers:a,body:JSON.stringify(s)},l=await w(()=>fetch(i,o));if(l.ok){let e=await l.json(),t={fid:e.fid||r,registrationStatus:2,refreshToken:e.refreshToken,authToken:p(e.authToken)};return t}throw await m("Create Installation",l)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function v(e){return new Promise(t=>{setTimeout(t,e)})}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let C=/^[cdef][\w-]{21}$/;/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function _(e){return`${e.appName}!${e.appId}`}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let S=new Map;function E(e,t){let r=_(e);I(r,t),function(e,t){let r=(!D&&"BroadcastChannel"in self&&((D=new BroadcastChannel("[Firebase] FID Change")).onmessage=e=>{I(e.data.key,e.data.fid)}),D);r&&r.postMessage({key:e,fid:t}),0===S.size&&D&&(D.close(),D=null)}(r,t)}function I(e,t){let r=S.get(e);if(r)for(let e of r)e(t)}let D=null,A="firebase-installations-store",T=null;function O(){return T||(T=(0,o.X3)("firebase-installations-database",1,{upgrade:(e,t)=>{0===t&&e.createObjectStore(A)}})),T}async function M(e,t){let r=_(e),i=await O(),a=i.transaction(A,"readwrite"),n=a.objectStore(A),s=await n.get(r);return await n.put(t,r),await a.done,s&&s.fid===t.fid||E(e,t.fid),t}async function L(e){let t=_(e),r=await O(),i=r.transaction(A,"readwrite");await i.objectStore(A).delete(t),await i.done}async function F(e,t){let r=_(e),i=await O(),a=i.transaction(A,"readwrite"),n=a.objectStore(A),s=await n.get(r),o=t(s);return void 0===o?await n.delete(r):await n.put(o,r),await a.done,o&&(!s||s.fid!==o.fid)&&E(e,o.fid),o}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function P(e){let t;let r=await F(e.appConfig,r=>{let i=function(e){let t=e||{fid:function(){try{let e=new Uint8Array(17),t=self.crypto||self.msCrypto;t.getRandomValues(e),e[0]=112+e[0]%16;let r=function(e){let t=/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function(e){let t=btoa(String.fromCharCode(...e));return t.replace(/\+/g,"-").replace(/\//g,"_")}(e);return t.substr(0,22)}(e);return C.test(r)?r:""}catch(e){return""}}(),registrationStatus:0};return R(t)}(r),a=function(e,t){if(0===t.registrationStatus){if(!navigator.onLine){let e=Promise.reject(f.create("app-offline"));return{installationEntry:t,registrationPromise:e}}let r={fid:t.fid,registrationStatus:1,registrationTime:Date.now()},i=N(e,r);return{installationEntry:r,registrationPromise:i}}return 1===t.registrationStatus?{installationEntry:t,registrationPromise:k(e)}:{installationEntry:t}}(e,i);return t=a.registrationPromise,a.installationEntry});return""===r.fid?{installationEntry:await t}:{installationEntry:r,registrationPromise:t}}async function N(e,t){try{let r=await y(e,t);return M(e.appConfig,r)}catch(r){throw d(r)&&409===r.customData.serverCode?await L(e.appConfig):await M(e.appConfig,{fid:t.fid,registrationStatus:0}),r}}async function k(e){let t=await B(e.appConfig);for(;1===t.registrationStatus;)await v(100),t=await B(e.appConfig);if(0===t.registrationStatus){let{installationEntry:t,registrationPromise:r}=await P(e);return r||t}return t}function B(e){return F(e,e=>{if(!e)throw f.create("installation-not-found");return R(e)})}function R(e){return 1===e.registrationStatus&&e.registrationTime+1e4<Date.now()?{fid:e.fid,registrationStatus:0}:e}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function j({appConfig:e,heartbeatServiceProvider:t},r){let i=function(e,{fid:t}){return`${g(e)}/${t}/authTokens:generate`}(e,r),a=function(e,{refreshToken:t}){let r=b(e);return r.append("Authorization",`${h} ${t}`),r}(e,r),n=t.getImmediate({optional:!0});if(n){let e=await n.getHeartbeatsHeader();e&&a.append("x-firebase-client",e)}let s={installation:{sdkVersion:u,appId:e.appId}},o={method:"POST",headers:a,body:JSON.stringify(s)},l=await w(()=>fetch(i,o));if(l.ok){let e=await l.json(),t=p(e);return t}throw await m("Generate Auth Token",l)}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function $(e,t=!1){let r;let i=await F(e.appConfig,i=>{var a;if(!V(i))throw f.create("not-registered");let n=i.authToken;if(!t&&2===(a=n).requestStatus&&!function(e){let t=Date.now();return t<e.creationTime||e.creationTime+e.expiresIn<t+36e5}(a))return i;if(1===n.requestStatus)return r=q(e,t),i;{if(!navigator.onLine)throw f.create("app-offline");let t=function(e){let t={requestStatus:1,requestTime:Date.now()};return Object.assign(Object.assign({},e),{authToken:t})}(i);return r=x(e,t),t}}),a=r?await r:i.authToken;return a}async function q(e,t){let r=await H(e.appConfig);for(;1===r.authToken.requestStatus;)await v(100),r=await H(e.appConfig);let i=r.authToken;return 0===i.requestStatus?$(e,t):i}function H(e){return F(e,e=>{if(!V(e))throw f.create("not-registered");let t=e.authToken;return 1===t.requestStatus&&t.requestTime+1e4<Date.now()?Object.assign(Object.assign({},e),{authToken:{requestStatus:0}}):e})}async function x(e,t){try{let r=await j(e,t),i=Object.assign(Object.assign({},t),{authToken:r});return await M(e.appConfig,i),r}catch(r){if(d(r)&&(401===r.customData.serverCode||404===r.customData.serverCode))await L(e.appConfig);else{let r=Object.assign(Object.assign({},t),{authToken:{requestStatus:0}});await M(e.appConfig,r)}throw r}}function V(e){return void 0!==e&&2===e.registrationStatus}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function z(e){let{installationEntry:t,registrationPromise:r}=await P(e);return r?r.catch(console.error):$(e).catch(console.error),t.fid}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function Q(e,t=!1){await U(e);let r=await $(e,t);return r.token}async function U(e){let{registrationPromise:t}=await P(e);t&&await t}function K(e){return f.create("missing-app-config-values",{valueName:e})}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let W="installations";(0,i.Xd)(new n.wA(W,e=>{let t=e.getProvider("app").getImmediate(),r=/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function(e){if(!e||!e.options)throw K("App Configuration");if(!e.name)throw K("App Name");for(let t of["projectId","apiKey","appId"])if(!e.options[t])throw K(t);return{appName:e.name,projectId:e.options.projectId,apiKey:e.options.apiKey,appId:e.options.appId}}(t),a=(0,i.qX)(t,"heartbeat");return{app:t,appConfig:r,heartbeatServiceProvider:a,_delete:()=>Promise.resolve()}},"PUBLIC")),(0,i.Xd)(new n.wA("installations-internal",e=>{let t=e.getProvider("app").getImmediate(),r=(0,i.qX)(t,W).getImmediate();return{getId:()=>z(r),getToken:e=>Q(r,e)}},"PRIVATE")),(0,i.KN)(l,c),(0,i.KN)(l,c,"esm2017");let Z="@firebase/remote-config",X="0.4.9";/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class G{constructor(){this.listeners=[]}addEventListener(e){this.listeners.push(e)}abort(){this.listeners.forEach(e=>e())}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */let J="remote-config",Y=new a.LL("remoteconfig","Remote Config",{"registration-window":"Undefined window object. This SDK only supports usage in a browser environment.","registration-project-id":"Undefined project identifier. Check Firebase app initialization.","registration-api-key":"Undefined API key. Check Firebase app initialization.","registration-app-id":"Undefined app identifier. Check Firebase app initialization.","storage-open":"Error thrown when opening storage. Original error: {$originalErrorMessage}.","storage-get":"Error thrown when reading from storage. Original error: {$originalErrorMessage}.","storage-set":"Error thrown when writing to storage. Original error: {$originalErrorMessage}.","storage-delete":"Error thrown when deleting from storage. Original error: {$originalErrorMessage}.","fetch-client-network":"Fetch client failed to connect to a network. Check Internet connection. Original error: {$originalErrorMessage}.","fetch-timeout":'The config fetch request timed out.  Configure timeout using "fetchTimeoutMillis" SDK setting.',"fetch-throttle":'The config fetch request timed out while in an exponential backoff state. Configure timeout using "fetchTimeoutMillis" SDK setting. Unix timestamp in milliseconds when fetch request throttling ends: {$throttleEndTimeMillis}.',"fetch-client-parse":"Fetch client could not parse response. Original error: {$originalErrorMessage}.","fetch-status":"Fetch server returned an HTTP error status. HTTP status: {$httpStatus}.","indexed-db-unavailable":"Indexed DB is not supported by current browser"}),ee=["1","true","t","yes","y","on"];class et{constructor(e,t=""){this._source=e,this._value=t}asString(){return this._value}asBoolean(){return"static"!==this._source&&ee.indexOf(this._value.toLowerCase())>=0}asNumber(){if("static"===this._source)return 0;let e=Number(this._value);return isNaN(e)&&(e=0),e}getSource(){return this._source}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function er(e=(0,i.Mq)()){e=(0,a.m9)(e);let t=(0,i.qX)(e,J);return t.getImmediate()}async function ei(e){let t=(0,a.m9)(e),[r,i]=await Promise.all([t._storage.getLastSuccessfulFetchResponse(),t._storage.getActiveConfigEtag()]);return!!r&&!!r.config&&!!r.eTag&&r.eTag!==i&&(await Promise.all([t._storageCache.setActiveConfig(r.config),t._storage.setActiveConfigEtag(r.eTag)]),!0)}async function ea(e){let t=(0,a.m9)(e),r=new G;setTimeout(async()=>{r.abort()},t.settings.fetchTimeoutMillis);try{await t._client.fetch({cacheMaxAgeMillis:t.settings.minimumFetchIntervalMillis,signal:r}),await t._storageCache.setLastFetchStatus("success")}catch(r){let e=r instanceof a.ZR&&-1!==r.code.indexOf("fetch-throttle")?"throttle":"failure";throw await t._storageCache.setLastFetchStatus(e),r}}function en(e,t){let r=(0,a.m9)(e);r._isInitializationComplete||r._logger.debug(`A value was requested for key "${t}" before SDK initialization completed. Await on ensureInitialized if the intent was to get a previously activated value.`);let i=r._storageCache.getActiveConfig();return i&&void 0!==i[t]?new et("remote",i[t]):r.defaultConfig&&void 0!==r.defaultConfig[t]?new et("default",String(r.defaultConfig[t])):(r._logger.debug(`Returning static value for key "${t}". Define a default or remote value if this is unintentional.`),new et("static"))}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class es{constructor(e,t,r,i){this.client=e,this.storage=t,this.storageCache=r,this.logger=i}isCachedDataFresh(e,t){if(!t)return this.logger.debug("Config fetch cache check. Cache unpopulated."),!1;let r=Date.now()-t,i=r<=e;return this.logger.debug(`Config fetch cache check. Cache age millis: ${r}. Cache max age millis (minimumFetchIntervalMillis setting): ${e}. Is cache hit: ${i}.`),i}async fetch(e){let[t,r]=await Promise.all([this.storage.getLastSuccessfulFetchTimestampMillis(),this.storage.getLastSuccessfulFetchResponse()]);if(r&&this.isCachedDataFresh(e.cacheMaxAgeMillis,t))return r;e.eTag=r&&r.eTag;let i=await this.client.fetch(e),a=[this.storageCache.setLastSuccessfulFetchTimestampMillis(Date.now())];return 200===i.status&&a.push(this.storage.setLastSuccessfulFetchResponse(i)),await Promise.all(a),i}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class eo{constructor(e,t,r,i,a,n){this.firebaseInstallations=e,this.sdkVersion=t,this.namespace=r,this.projectId=i,this.apiKey=a,this.appId=n}async fetch(e){let t,r,i;let[a,n]=await Promise.all([this.firebaseInstallations.getId(),this.firebaseInstallations.getToken()]),s=window.FIREBASE_REMOTE_CONFIG_URL_BASE||"https://firebaseremoteconfig.googleapis.com",o=`${s}/v1/projects/${this.projectId}/namespaces/${this.namespace}:fetch?key=${this.apiKey}`,l={"Content-Type":"application/json","Content-Encoding":"gzip","If-None-Match":e.eTag||"*"},c={sdk_version:this.sdkVersion,app_instance_id:a,app_instance_id_token:n,app_id:this.appId,language_code:/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function(e=navigator){return e.languages&&e.languages[0]||e.language}()},u={method:"POST",headers:l,body:JSON.stringify(c)},h=fetch(o,u),f=new Promise((t,r)=>{e.signal.addEventListener(()=>{let e=Error("The operation was aborted.");e.name="AbortError",r(e)})});try{await Promise.race([h,f]),t=await h}catch(t){let e="fetch-client-network";throw(null==t?void 0:t.name)==="AbortError"&&(e="fetch-timeout"),Y.create(e,{originalErrorMessage:null==t?void 0:t.message})}let d=t.status,g=t.headers.get("ETag")||void 0;if(200===t.status){let e;try{e=await t.json()}catch(e){throw Y.create("fetch-client-parse",{originalErrorMessage:null==e?void 0:e.message})}r=e.entries,i=e.state}if("INSTANCE_STATE_UNSPECIFIED"===i?d=500:"NO_CHANGE"===i?d=304:("NO_TEMPLATE"===i||"EMPTY_CONFIG"===i)&&(r={}),304!==d&&200!==d)throw Y.create("fetch-status",{httpStatus:d});return{status:d,eTag:g,config:r}}}class el{constructor(e,t){this.client=e,this.storage=t}async fetch(e){let t=await this.storage.getThrottleMetadata()||{backoffCount:0,throttleEndTimeMillis:Date.now()};return this.attemptFetch(e,t)}async attemptFetch(e,{throttleEndTimeMillis:t,backoffCount:r}){var i;await (i=e.signal,new Promise((e,r)=>{let a=Math.max(t-Date.now(),0),n=setTimeout(e,a);i.addEventListener(()=>{clearTimeout(n),r(Y.create("fetch-throttle",{throttleEndTimeMillis:t}))})}));try{let t=await this.client.fetch(e);return await this.storage.deleteThrottleMetadata(),t}catch(i){if(!function(e){if(!(e instanceof a.ZR)||!e.customData)return!1;let t=Number(e.customData.httpStatus);return 429===t||500===t||503===t||504===t}(i))throw i;let t={throttleEndTimeMillis:Date.now()+(0,a.$s)(r),backoffCount:r+1};return await this.storage.setThrottleMetadata(t),this.attemptFetch(e,t)}}}class ec{constructor(e,t,r,i,a){this.app=e,this._client=t,this._storageCache=r,this._storage=i,this._logger=a,this._isInitializationComplete=!1,this.settings={fetchTimeoutMillis:6e4,minimumFetchIntervalMillis:432e5},this.defaultConfig={}}get fetchTimeMillis(){return this._storageCache.getLastSuccessfulFetchTimestampMillis()||-1}get lastFetchStatus(){return this._storageCache.getLastFetchStatus()||"no-fetch-yet"}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */function eu(e,t){let r=e.target.error||void 0;return Y.create(t,{originalErrorMessage:r&&(null==r?void 0:r.message)})}let eh="app_namespace_store";class Storage{constructor(e,t,r,i=new Promise((e,t)=>{try{let r=indexedDB.open("firebase_remote_config",1);r.onerror=e=>{t(eu(e,"storage-open"))},r.onsuccess=t=>{e(t.target.result)},r.onupgradeneeded=e=>{let t=e.target.result;0===e.oldVersion&&t.createObjectStore(eh,{keyPath:"compositeKey"})}}catch(e){t(Y.create("storage-open",{originalErrorMessage:null==e?void 0:e.message}))}})){this.appId=e,this.appName=t,this.namespace=r,this.openDbPromise=i}getLastFetchStatus(){return this.get("last_fetch_status")}setLastFetchStatus(e){return this.set("last_fetch_status",e)}getLastSuccessfulFetchTimestampMillis(){return this.get("last_successful_fetch_timestamp_millis")}setLastSuccessfulFetchTimestampMillis(e){return this.set("last_successful_fetch_timestamp_millis",e)}getLastSuccessfulFetchResponse(){return this.get("last_successful_fetch_response")}setLastSuccessfulFetchResponse(e){return this.set("last_successful_fetch_response",e)}getActiveConfig(){return this.get("active_config")}setActiveConfig(e){return this.set("active_config",e)}getActiveConfigEtag(){return this.get("active_config_etag")}setActiveConfigEtag(e){return this.set("active_config_etag",e)}getThrottleMetadata(){return this.get("throttle_metadata")}setThrottleMetadata(e){return this.set("throttle_metadata",e)}deleteThrottleMetadata(){return this.delete("throttle_metadata")}async get(e){let t=await this.openDbPromise;return new Promise((r,i)=>{let a=t.transaction([eh],"readonly"),n=a.objectStore(eh),s=this.createCompositeKey(e);try{let e=n.get(s);e.onerror=e=>{i(eu(e,"storage-get"))},e.onsuccess=e=>{let t=e.target.result;t?r(t.value):r(void 0)}}catch(e){i(Y.create("storage-get",{originalErrorMessage:null==e?void 0:e.message}))}})}async set(e,t){let r=await this.openDbPromise;return new Promise((i,a)=>{let n=r.transaction([eh],"readwrite"),s=n.objectStore(eh),o=this.createCompositeKey(e);try{let e=s.put({compositeKey:o,value:t});e.onerror=e=>{a(eu(e,"storage-set"))},e.onsuccess=()=>{i()}}catch(e){a(Y.create("storage-set",{originalErrorMessage:null==e?void 0:e.message}))}})}async delete(e){let t=await this.openDbPromise;return new Promise((r,i)=>{let a=t.transaction([eh],"readwrite"),n=a.objectStore(eh),s=this.createCompositeKey(e);try{let e=n.delete(s);e.onerror=e=>{i(eu(e,"storage-delete"))},e.onsuccess=()=>{r()}}catch(e){i(Y.create("storage-delete",{originalErrorMessage:null==e?void 0:e.message}))}})}createCompositeKey(e){return[this.appId,this.appName,this.namespace,e].join()}}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */class ef{constructor(e){this.storage=e}getLastFetchStatus(){return this.lastFetchStatus}getLastSuccessfulFetchTimestampMillis(){return this.lastSuccessfulFetchTimestampMillis}getActiveConfig(){return this.activeConfig}async loadFromStorage(){let e=this.storage.getLastFetchStatus(),t=this.storage.getLastSuccessfulFetchTimestampMillis(),r=this.storage.getActiveConfig(),i=await e;i&&(this.lastFetchStatus=i);let a=await t;a&&(this.lastSuccessfulFetchTimestampMillis=a);let n=await r;n&&(this.activeConfig=n)}setLastFetchStatus(e){return this.lastFetchStatus=e,this.storage.setLastFetchStatus(e)}setLastSuccessfulFetchTimestampMillis(e){return this.lastSuccessfulFetchTimestampMillis=e,this.storage.setLastSuccessfulFetchTimestampMillis(e)}setActiveConfig(e){return this.activeConfig=e,this.storage.setActiveConfig(e)}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */async function ed(e){return e=(0,a.m9)(e),await ea(e),ei(e)}(0,i.Xd)(new n.wA(J,function(e,{instanceIdentifier:t}){let r=e.getProvider("app").getImmediate(),n=e.getProvider("installations-internal").getImmediate();if("undefined"==typeof window)throw Y.create("registration-window");if(!(0,a.hl)())throw Y.create("indexed-db-unavailable");let{projectId:o,apiKey:l,appId:c}=r.options;if(!o)throw Y.create("registration-project-id");if(!l)throw Y.create("registration-api-key");if(!c)throw Y.create("registration-app-id");t=t||"firebase";let u=new Storage(c,r.name,t),h=new ef(u),f=new s.Yd(Z);f.logLevel=s.in.ERROR;let d=new eo(n,i.Jn,t,o,l,c),g=new el(d,u),p=new es(g,u,h,f),m=new ec(r,p,h,u,f);return function(e){let t=(0,a.m9)(e);t._initializePromise||(t._initializePromise=t._storageCache.loadFromStorage().then(()=>{t._isInitializationComplete=!0})),t._initializePromise}(m),m},"PUBLIC").setMultipleInstances(!0)),(0,i.KN)(Z,X),(0,i.KN)(Z,X,"esm2017")},80686:function(e,t,r){"use strict";var i;let a,n;r.d(t,{X3:function(){return p}});let s=(e,t)=>t.some(t=>e instanceof t),o=new WeakMap,l=new WeakMap,c=new WeakMap,u=new WeakMap,h=new WeakMap,f={get(e,t,r){if(e instanceof IDBTransaction){if("done"===t)return l.get(e);if("objectStoreNames"===t)return e.objectStoreNames||c.get(e);if("store"===t)return r.objectStoreNames[1]?void 0:r.objectStore(r.objectStoreNames[0])}return d(e[t])},set:(e,t,r)=>(e[t]=r,!0),has:(e,t)=>e instanceof IDBTransaction&&("done"===t||"store"===t)||t in e};function d(e){var t;if(e instanceof IDBRequest)return function(e){let t=new Promise((t,r)=>{let i=()=>{e.removeEventListener("success",a),e.removeEventListener("error",n)},a=()=>{t(d(e.result)),i()},n=()=>{r(e.error),i()};e.addEventListener("success",a),e.addEventListener("error",n)});return t.then(t=>{t instanceof IDBCursor&&o.set(t,e)}).catch(()=>{}),h.set(t,e),t}(e);if(u.has(e))return u.get(e);let r="function"==typeof(t=e)?t!==IDBDatabase.prototype.transaction||"objectStoreNames"in IDBTransaction.prototype?(n||(n=[IDBCursor.prototype.advance,IDBCursor.prototype.continue,IDBCursor.prototype.continuePrimaryKey])).includes(t)?function(...e){return t.apply(g(this),e),d(o.get(this))}:function(...e){return d(t.apply(g(this),e))}:function(e,...r){let i=t.call(g(this),e,...r);return c.set(i,e.sort?e.sort():[e]),d(i)}:(t instanceof IDBTransaction&&function(e){if(l.has(e))return;let t=new Promise((t,r)=>{let i=()=>{e.removeEventListener("complete",a),e.removeEventListener("error",n),e.removeEventListener("abort",n)},a=()=>{t(),i()},n=()=>{r(e.error||new DOMException("AbortError","AbortError")),i()};e.addEventListener("complete",a),e.addEventListener("error",n),e.addEventListener("abort",n)});l.set(e,t)}(t),s(t,a||(a=[IDBDatabase,IDBObjectStore,IDBIndex,IDBCursor,IDBTransaction])))?new Proxy(t,f):t;return r!==e&&(u.set(e,r),h.set(r,e)),r}let g=e=>h.get(e);function p(e,t,{blocked:r,upgrade:i,blocking:a,terminated:n}={}){let s=indexedDB.open(e,t),o=d(s);return i&&s.addEventListener("upgradeneeded",e=>{i(d(s.result),e.oldVersion,e.newVersion,d(s.transaction),e)}),r&&s.addEventListener("blocked",e=>r(e.oldVersion,e.newVersion,e)),o.then(e=>{n&&e.addEventListener("close",()=>n()),a&&e.addEventListener("versionchange",e=>a(e.oldVersion,e.newVersion,e))}).catch(()=>{}),o}let m=["get","getKey","getAll","getAllKeys","count"],b=["put","add","delete","clear"],w=new Map;function y(e,t){if(!(e instanceof IDBDatabase&&!(t in e)&&"string"==typeof t))return;if(w.get(t))return w.get(t);let r=t.replace(/FromIndex$/,""),i=t!==r,a=b.includes(r);if(!(r in(i?IDBIndex:IDBObjectStore).prototype)||!(a||m.includes(r)))return;let n=async function(e,...t){let n=this.transaction(e,a?"readwrite":"readonly"),s=n.store;return i&&(s=s.index(t.shift())),(await Promise.all([s[r](...t),a&&n.done]))[0]};return w.set(t,n),n}f={...i=f,get:(e,t,r)=>y(e,t)||i.get(e,t,r),has:(e,t)=>!!y(e,t)||i.has(e,t)}}}]);