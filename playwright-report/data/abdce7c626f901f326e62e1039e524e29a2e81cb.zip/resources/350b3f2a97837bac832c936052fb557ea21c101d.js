const Footer = () => (
  <p className="absolute bottom-[32px] text-center text-[12px] text-gray-400">
    2024 © PT. Elektronik Distribusi Otomatisasi Terkemuka
  </p>
)
