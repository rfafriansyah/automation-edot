const TextInput = (props) => {
  const {
    id,
    type,
    disabled,
    value,
    onChange,
    onKeyDown,
    label,
    name,
    placeholder,
    className,
    containerClassName,
    errorMessage,
    isError,
    locals
  } = props

  const [inputType, setInputType] = useState(type)
  const [showPassword, setShowPassword] = useState(false)

  const togglePassword = (val) => {
    setShowPassword(val)
    setInputType(val ? 'text' : 'password')
  }

  return (
    <div className={containerClassName}>
      {label && (
        <label className="text-[12px] text-gray-500 mb-1">{label}</label>
      )}
      <div className="relative">
        <input
          id={id}
          type={inputType}
          name={name}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => onKeyDown ? onKeyDown(e) : null }
          placeholder={placeholder}
          className={`${className} w-full rounded px-3 py-2 border-[1px] ${(errorMessage || isError) ? 'border-red-400' : 'focus:border-sky-300 border-gray-100'} outline-0 text-[12px]`}
          disabled={disabled}
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck="false"
        />
        {type === 'password' && (
          <div className="absolute right-[12px] top-[10px] cursor-pointer" onClick={() => togglePassword(!showPassword)}>
            <img src={`${locals.host}/asset/image/${!showPassword ? 'eye-hidden' : 'eye-shown'}.svg`} width="18px" />
          </div>
        )}
      </div>
      {errorMessage && (
        <p className="text-[11px] text-red-500 mt-1">{errorMessage}</p>
      )}
    </div>
  )
}
