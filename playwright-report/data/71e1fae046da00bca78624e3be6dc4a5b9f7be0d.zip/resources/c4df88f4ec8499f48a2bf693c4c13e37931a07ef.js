const getCookie = (cookieName) => {
  const cookies = document.cookie.split(';');

  for (let cookie of cookies) {
    cookie = cookie.trim();

    if (cookie.startsWith(`${cookieName}=`)) {
      return cookie.substring(cookieName.length + 1);
    }
  }

  return null;
}

const trackEvent = async (data, eventName, eventProperties = {}) => {
  const eventData = {
    event: eventName,
    properties: eventProperties,
    anonymousId: getCookie('__eventn_id')
  };

  try {
    const response = await fetch(`${data.jitsuHost}/api/s/track`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Write-Key': data.jitsuWriteKey,
      },
      body: JSON.stringify(eventData),
    });

    if (!response.ok && data?.env !== 'production') {
      throw new Error(`HTTP error! Status: ${response.status}`);
    }

    if (data?.env !== 'production') console.log('Event tracked successfully:', eventName);
  } catch (error) {
    if (data?.env !== 'production') console.error('Error tracking event:', error);
  }
}
