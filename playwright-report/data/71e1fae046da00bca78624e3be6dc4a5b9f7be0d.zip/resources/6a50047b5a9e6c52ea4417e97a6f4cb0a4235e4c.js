const Header = (props) => {
  const { title, smallText, locals, isError, noGap } = props;

  return (
    <div>
      <img src={locals?.client?._image || `${locals.host}/asset/image/edot-logo-new.svg`} width="90px" className="mx-auto self-center" />
      <p className={`text-center text-[12px] text-gray-800 mt-1 ${noGap ? '' : 'mb-6'}`}>Account Center</p>
      {title && (
        <p className={`text-center font-bold ${isError ? 'text-red-500' : 'text-gray-800'} ${!smallText ? 'mb-6' : 'mb-1'}`}>{title}</p>
      )}
      {smallText && (
        <p className={`text-sm text-center mb-6 text-gray-800 ${noGap ? '' : 'mb-6'}`}>{smallText}</p>
      )}
    </div>
  )
}
