const Button = (props) => {
  const {
    id,
    type,
    typeClass,
    text,
    onClick,
    disabled,
    className,
    icon,
    loading,
    locals
  } = props

  const typeClassName = {
    primary: 'rounded p-2 bg-sky-500 hover:bg-sky-400 text-white disabled:bg-neutral-200 disabled:text-neutral-400 text-sm font-bold',
    primaryBordered: 'rounded p-2 text-sky-400 border-[1px] border-sky-400 text-sm font-bold hover:bg-gray-50',
    primaryLink: 'text-sky-400 font-bold disabled:text-gray-300',
    primaryLinkSmall: 'text-sky-400 font-bold disabled:text-gray-300 text-[8px]'
  }[typeClass];

  return (
    <button
      id={id}
      type={type}
      className={`${typeClassName} ${className}`}
      onClick={() => onClick()}
      disabled={disabled}
    >
      {loading && (
        <img src={`${locals.host}/asset/image/loading${disabled ? '-gray' : ''}.svg`} width="20px" className="absolute animate-spin" />
      )}
      {icon && (
        <img src={icon} width="20px" className="absolute" />
      )}
      {text}
    </button>
  )
}
