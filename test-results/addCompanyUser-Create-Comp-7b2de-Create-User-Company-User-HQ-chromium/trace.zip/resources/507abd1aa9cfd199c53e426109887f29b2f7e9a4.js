const Modal = (props) => {
  const {
    show,
    children,
    className,
    onClose,
    preventBackdropClose
  } = props

  const onClickBackdrop = () => {
    // console.log('click')
    if (!preventBackdropClose) onClose();
  };

  return (
    <>
      <div className={`${show ? 'opacity-100 z-40' : 'opacity-0 -z-40'} fixed transition-opacity ease-in-out delay-150 inset-0 bg-black bg-opacity-40 flex justify-center items-center backdrop-blur-sm`}>
        <div className={`absolute w-full h-full ${show ? 'opacity-100 z-40' : 'opacity-0 -z-40'}`} onClick={() => onClickBackdrop()} />
        <div
          className={`${className} w-[400px] rounded-[16px] border-2 border-neutral-100 shadow-sm flex flex-col p-8 mb-8 bg-white z-50`}
        >
          <div className="overflow-y-auto">
            {children}
          </div>
        </div>
      </div>
    </>
  )
}
