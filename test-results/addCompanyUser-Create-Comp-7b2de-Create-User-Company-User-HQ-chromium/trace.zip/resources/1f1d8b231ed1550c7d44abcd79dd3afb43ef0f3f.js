const emailorUserValidation = (val, isEmailOnly = false) => {
  const message = 'Wrong email format';
  const isEmail = /(@)/g.test(val);

  if (val !== '') {
    if (isEmail) {
      if (/^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/.test(val)) {
        return null;
      } else {
        return message;
      }
    } else {
      return !isEmailOnly ? null : message;
    }
  } else {
    return null;
  }
}

const emailValidation = (val) => {
  return emailorUserValidation(val, true);
}

const phoneValidation = (val) => {
  const min = 8;
  const max = 15;
  const isPhone = /^$|^([0-9,+]{0,99})?$/.test(val);

  if (val !== '') {
    if (isPhone) {
      if (val.length < min) {
        return `Phone number is too short, min. ${min} digit`;
      } else if (val.length > max) {
        return `Phone number is too long, max. ${max} digit`
      } else {
        return null;
      }
    } else {
      return 'Wrong phone number format';
    }
  } else {
    return null;
  }
}

const passwordValidation = (val) => {
  const charLimit = /^.{8,999}$/.test(val);
  const charSpecial = /(?=.*?[^a-zA-Z0-9]{1})/.test(val);
  const charCase = /(?=.*?[A-Z]{1})(?=.*?[a-z]{1})/.test(val);
  const charNumber = /(?=.*?[0-9]{1})/.test(val);

  return ([charLimit, charSpecial, charCase, charNumber]);
}

const fullNameValidation = (val) => {
  const charLimit = /^.{3,999}$/.test(val);
  const charNumber = /(?=.*?[0-9]{1})/.test(val);

  return ([charLimit, charNumber]);
}